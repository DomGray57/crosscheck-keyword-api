# CrossCheck Keyword API

A FastAPI-based backend that simulates cross-platform keyword research (Google Trends, TikTok, Pinterest, Etsy, Reddit).

## Endpoints

### POST `/crosscheck_keyword`
Payload:
```json
{
  "keyword": "your keyword here"
}
```

Returns simulated trend data for multiple platforms.

---

Built for GPT tool integration.
